package Task1

type Person struct {
	name string
	age  int
}
