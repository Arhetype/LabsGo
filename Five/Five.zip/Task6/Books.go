package Task6

import "fmt"

func Books() {

	fmt.Println("Task 6")

	book := Book{
		Title:  "1984",
		Author: "George Orwell",
		Year:   1949,
	}

	fmt.Println(book)
}
