package Task3

type Circle struct {
	Radius float64
}
