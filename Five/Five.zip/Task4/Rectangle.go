package Task4

type Rectangle struct {
	Width  float64
	Height float64
}
