package Task4

type Shape interface {
	Area() float64
}
