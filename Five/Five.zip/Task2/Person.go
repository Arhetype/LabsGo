package Task2

type Person struct {
	name string
	age  int
}
