package Task2

func (p *Person) Birthday() {
	p.age++
}
