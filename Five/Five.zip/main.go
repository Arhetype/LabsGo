package main

import (
	"Five/Task1"
	"Five/Task2"
	"Five/Task3"
	"Five/Task4"
	"Five/Task5"
	"Five/Task6"
)

func main() {
	Task1.List()
	Task2.Lists()
	Task3.Answer()
	Task4.Figures()
	Task5.Ans()
	Task6.Books()
}
